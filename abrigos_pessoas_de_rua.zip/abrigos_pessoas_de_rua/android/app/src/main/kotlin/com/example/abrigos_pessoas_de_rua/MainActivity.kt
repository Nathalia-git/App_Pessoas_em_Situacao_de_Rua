package com.example.abrigos_pessoas_de_rua

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
